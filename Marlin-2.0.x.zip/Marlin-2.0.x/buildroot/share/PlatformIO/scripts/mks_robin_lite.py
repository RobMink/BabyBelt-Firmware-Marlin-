#
# mks_robin_lite.py
#
import robin
robin.prepare("0x08005000", "mks_robin_lite.ld", "mksLite.bin")
